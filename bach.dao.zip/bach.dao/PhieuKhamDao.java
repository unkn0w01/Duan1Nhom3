/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.PhieuKham;
import java.util.*;
import java.sql.*;

/**
 *
 * @author buiva
 */
public class PhieuKhamDao {

    public void add(PhieuKham pk) {
        try {
            Connection con = DataBase.getConnect();
            String sql = "INSERT INTO PhieuKham(MaPK, MaBN, MaBS, STT, ChuanDoan, NgayKham, MaThuoc) VALUES(?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, pk.getMaPK());
            statement.setString(2, pk.getMaBN());
            statement.setString(3, pk.getMaBS());
            statement.setString(4, pk.getSTT());
            statement.setString(5, pk.getChuanDoan());
            statement.setString(6, pk.getNgayKham());
            statement.setString(7, pk.getMaThuoc());
            if (statement.executeUpdate() > 0) {
                System.out.println("Insert thành công");
            } else {
                System.out.println("Insert thất bại");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi thêm phiếu khám vào data");
        }
    }

    public void update(PhieuKham pk) {
        try {
            Connection con = DataBase.getConnect();
            String sql = "UPDATE PHIEUKHAM SET MaBN = ?, MaBS = ?, STT = ?, ChuanDoan = ?, NgayKham = ?, MaThuoc = ? WHERE MaPK)";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(7, pk.getMaPK());
            statement.setString(1, pk.getMaBN());
            statement.setString(2, pk.getMaBS());
            statement.setString(3, pk.getSTT());
            statement.setString(4, pk.getChuanDoan());
            statement.setString(5, pk.getNgayKham());
            statement.setString(6, pk.getMaThuoc());
            if (statement.executeUpdate() > 0) {
                System.out.println("Update thành công");
            } else {
                System.out.println("Update thất bại");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi update phiếu khám vào data");
        }
    }

    public void delete(String maPK) {
        try {
            Connection con = DataBase.getConnect();
            String sql = "DELETE FROM PHIEUKHAM WHERE MaPK = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, maPK);

            if (statement.executeUpdate() > 0) {
                System.out.println("Delete thành công");
            } else {
                System.out.println("Delete thất bại");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi xoá phiếu khám khỏi data" + e);
        }
    }

    public List<PhieuKham> getAll() {
        List<PhieuKham> listPK = new ArrayList();
        try {
            Connection con = DataBase.getConnect();
            String sql = "SELECT * FROM PHIEUKHAM";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                PhieuKham pk = new PhieuKham(result.getString("MaPK"), result.getString("MaBN"),
                        result.getString("MaBS"), result.getString("STT"), result.getString("ChuanDoan"),
                        result.getString("NgayKham"), result.getString("MaThuoc"));
                listPK.add(pk);
            }
            return listPK;
        } catch (SQLException e) {
            System.out.println("Lấy dữ liệu từ table lỗi" + e);
            return null;
        }
    }

    public PhieuKham getById(String maPK) {
        try {
            Connection con = DataBase.getConnect();
            String sql = "SELECT * FROM PHIEUKHAM WHERE MaPK = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, maPK);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                PhieuKham pk = new PhieuKham(result.getString("MaPK"), result.getString("MaBN"),
                         result.getString("MaBS"), result.getString("STT"), result.getString("ChuanDoan"),
                        result.getString("NgayKham"), result.getString("MaThuoc"));
                return pk;
            }

        } catch (SQLException e) {
            System.out.println("Lỗi tìm kiếm phiếu khám trong data" + e);
        }
        return null;
    }
}
