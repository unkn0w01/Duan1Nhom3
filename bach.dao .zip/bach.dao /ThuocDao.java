/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.Thuoc;
import java.util.*;
import java.sql.*;

/**
 *
 * @author buiva
 */
public class ThuocDao {

    public void add(Thuoc th) {
        try {
            Connection con = DataBase.getConnect();
            String sql = "INSERT INTO THUOC(MaThuoc, TenThuoc, TacDung, LieuLuong, DonGia, ThanhTien) VALUES(?, ?, ?, ?, ? ,?)";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, th.getMaThuoc());
            statement.setString(2, th.getTenThuoc());
            statement.setString(3, th.getTacDung());
            statement.setString(4, th.getLieuLuong());
            statement.setFloat(5, th.getDonGia());
            statement.setFloat(6, th.getThanhTien());

            if (statement.executeUpdate() > 0) {
                System.out.println("Insert thành công");
            } else {
                System.out.println("Insert thất bại");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi thêm thuốc vào data" + e);
        }
    }

    public void update(Thuoc th) {
        try {
            Connection con = DataBase.getConnect();
            String sql = "UPDATE THUOC SET TenThuoc = ?, TacDung = ?, LieuLuong = ?, DonGia = ?, ThanhTien = ? WHERE MaThuoc";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(6, th.getMaThuoc());
            statement.setString(1, th.getTenThuoc());
            statement.setString(2, th.getTacDung());
            statement.setString(3, th.getLieuLuong());
            statement.setFloat(4, th.getDonGia());
            statement.setFloat(5, th.getThanhTien());

            if (statement.executeUpdate() > 0) {
                System.out.println("Update thành công");
            } else {
                System.out.println("Update thất bại");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi update thuốc vào data" + e);
        }        
    }
    
    public void delete(String maThuoc) {
        try {
            Connection con = DataBase.getConnect();
            String sql = "DELETE FROM THUOC WHERE MaThuoc = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, maThuoc);

            if (statement.executeUpdate() > 0) {
                System.out.println("Delete thành công");
            } else {
                System.out.println("Delete thất bại");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi xoá thuốc khỏi data" + e);
        }
    }

    public List<Thuoc> getAll() {
        List<Thuoc> listTH = new ArrayList();
        try {
            Connection con = DataBase.getConnect();
            String sql = "SELECT * FROM THUOC";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Thuoc th = new Thuoc(result.getString("MaThuoc"), result.getString("TenThuoc"),
                        result.getString("TacDung"), result.getString("LieuLuong"), result.getFloat("DonGia"),
                        result.getFloat("ThanhTien"));
                listTH.add(th);
            }
            return listTH;
        } catch (SQLException e) {
            System.out.println("Lấy dữ liệu từ table lỗi" + e);
            return null;
        }
    }

    public Thuoc getById(String maThuoc) {
        try {
            Connection con = DataBase.getConnect();
            String sql = "SELECT * FROM THUOC WHERE MaThuoc = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, maThuoc);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                Thuoc th = new Thuoc(result.getString("MaThuoc"), result.getString("TenThuoc"), result.getString("TacDung"),
                        result.getString("LieuLuong"), result.getFloat("DonGia"), result.getFloat("ThanhTien"));
                return th;
            }

        } catch (SQLException e) {
            System.out.println("Lỗi tìm kiếm thuốc trong data" + e);
        }
        return null;
    }
}

  
