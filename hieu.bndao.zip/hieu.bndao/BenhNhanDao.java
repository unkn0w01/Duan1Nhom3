/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import entity.BenhNhan;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author buiva
 */
public class BenhNhanDao {
    Connection cn = database.getConnection();
    public List<BenhNhan> getAll(){
        List<BenhNhan> lbn = new ArrayList<>();
        try {
            String sql = "select * from BENHNHAN";
            PreparedStatement pr = cn.prepareStatement(sql);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhan bn = new BenhNhan(rs.getString("MaBN"), rs.getString("TenBN"), rs.getString("NgaySinh"),
                        rs.getBoolean("GioiTinh"), rs.getString("DiaChi"), rs.getString("SDT"));
                lbn.add(bn);
            }
        } catch (SQLException e) {
            System.out.println("Loi lay du lieu" + e);
            return null;
        }
        return lbn;
    }
    public void insert(BenhNhan bn){
        try {
            String sql = "insert into BENHNHAN(MaBN,TenBN,NgaySinh,GioiTinh,DiaChi,SDT) values (?,?,?,?,?,?)";
            PreparedStatement pr = cn.prepareStatement(sql);
            pr.setString(1, bn.getMaBN());
            pr.setString(2, bn.getTenBN());
            pr.setString(3, bn.getNgaySinh());
            pr.setBoolean(4, bn.getGioiTinh());
            pr.setString(5, bn.getDiaChi());
            pr.setString(6, bn.getSDT());
            if(pr.executeUpdate() > 0){
                System.out.println("Insert thanh cong");
            }else {
                System.out.println("Insert that bai");
            }
        } catch (SQLException e) {
            System.out.println("insert that bai" + e);
        }
    }
    public void update(BenhNhan bn){
        try {
            String sql = "update BENHNHAN set TenBN = ?,NgaySinh = ?,GioiTinh = ?,DiaChi = ?,SDT = ? where MaBN = ?";
            PreparedStatement pr = cn.prepareStatement(sql);
            pr.setString(6, bn.getMaBN());
            pr.setString(1, bn.getTenBN());
            pr.setString(2, bn.getNgaySinh());
            pr.setBoolean(3, bn.getGioiTinh());
            pr.setString(4, bn.getDiaChi());
            pr.setString(5, bn.getSDT());
            if(pr.executeUpdate() > 0){
                System.out.println("update thanh cong");
            }else {
                System.out.println("update that bai");
            }
        } catch (SQLException e) {
            System.out.println("update that bai" + e);
        }        
    }
    public void delete(String maBN){
        try {
            String sql = "delete from BENHNHAN where MaBN = ?";
            PreparedStatement pr = cn.prepareStatement(sql);
            pr.setString(1, maBN);
            if(pr.executeUpdate() > 0){
                System.out.println("delete thanh cong");
            }else {
                System.out.println("delete that bai");
            }            
        } catch (SQLException e) {
            System.out.println("delete that bai" + e);
            
        }
    }
    public BenhNhan selectByID(String maBN){
        try {
            String sql = "select * form BENHNHAN where MABN = ?";
            PreparedStatement pr = cn.prepareStatement(sql);
            pr.setString(1, maBN);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhan bn = new BenhNhan(rs.getString("MaBN"), rs.getString("TenBN"), rs.getString("NgaySinh"),
                        rs.getBoolean("GioiTinh"), rs.getString("DiaChi"), rs.getString("SDT"));
                return bn;
            }
        } catch (SQLException e) {
            System.out.println("loi tim" + e);
        }
        return null;
    }
}
