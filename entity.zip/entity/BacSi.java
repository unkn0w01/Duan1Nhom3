package entity;

public class BacSi {
    private String maBS, tenBS;
    private boolean gioiTinh;
    private String diaChi, chuyenKhoa, SDT;

    public BacSi() {
    }

    public BacSi(String maBS, String tenBS, boolean gioiTinh, String diaChi, String chuyenKhoa, String SDT) {
        this.maBS = maBS;
        this.tenBS = tenBS;
        this.gioiTinh = gioiTinh;
        this.diaChi = diaChi;
        this.chuyenKhoa = chuyenKhoa;
        this.SDT = SDT;
    }

    public String getMaBS() {
        return maBS;
    }

    public void setMaBS(String maBS) {
        this.maBS = maBS;
    }

    public String getTenBS() {
        return tenBS;
    }

    public void setTenBS(String tenBS) {
        this.tenBS = tenBS;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getChuyenKhoa() {
        return chuyenKhoa;
    }

    public void setChuyenKhoa(String chuyenKhoa) {
        this.chuyenKhoa = chuyenKhoa;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }
    
}
