package entity;

public class PhieuKham {
    private String maPK, maBN, maBS, STT, chuanDoan, ngayKham, maThuoc;

    public PhieuKham() {
    }

    public PhieuKham(String maPK, String maBN, String maBS, String STT, String chuanDoan, String ngayKham, String maThuoc) {
        this.maPK = maPK;
        this.maBN = maBN;
        this.maBS = maBS;
        this.STT = STT;
        this.chuanDoan = chuanDoan;
        this.ngayKham = ngayKham;
        this.maThuoc = maThuoc;
    }

    public String getMaPK() {
        return maPK;
    }

    public void setMaPK(String maPK) {
        this.maPK = maPK;
    }

    public String getMaBN() {
        return maBN;
    }

    public void setMaBN(String maBN) {
        this.maBN = maBN;
    }

    public String getMaBS() {
        return maBS;
    }

    public void setMaBS(String maBS) {
        this.maBS = maBS;
    }

    public String getSTT() {
        return STT;
    }

    public void setSTT(String STT) {
        this.STT = STT;
    }

    public String getChuanDoan() {
        return chuanDoan;
    }

    public void setChuanDoan(String chuanDoan) {
        this.chuanDoan = chuanDoan;
    }

    public String getNgayKham() {
        return ngayKham;
    }

    public void setNgayKham(String ngayKham) {
        this.ngayKham = ngayKham;
    }

    public String getMaThuoc() {
        return maThuoc;
    }

    public void setMaThuoc(String maThuoc) {
        this.maThuoc = maThuoc;
    }
    
}
