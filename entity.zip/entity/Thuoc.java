package entity;

public class Thuoc {
    private String maThuoc, tenThuoc, tacDung, lieuLuong;
    private float donGia, thanhTien;

    public Thuoc() {
    }

    public Thuoc(String maThuoc, String tenThuoc, String tacDung, String lieuLuong, float donGia, float thanhTien) {
        this.maThuoc = maThuoc;
        this.tenThuoc = tenThuoc;
        this.tacDung = tacDung;
        this.lieuLuong = lieuLuong;
        this.donGia = donGia;
        this.thanhTien = thanhTien;
    }

    public String getMaThuoc() {
        return maThuoc;
    }

    public void setMaThuoc(String maThuoc) {
        this.maThuoc = maThuoc;
    }

    public String getTenThuoc() {
        return tenThuoc;
    }

    public void setTenThuoc(String tenThuoc) {
        this.tenThuoc = tenThuoc;
    }

    public String getTacDung() {
        return tacDung;
    }

    public void setTacDung(String tacDung) {
        this.tacDung = tacDung;
    }

    public String getLieuLuong() {
        return lieuLuong;
    }

    public void setLieuLuong(String lieuLuong) {
        this.lieuLuong = lieuLuong;
    }

    public float getDonGia() {
        return donGia;
    }

    public void setDonGia(float donGia) {
        this.donGia = donGia;
    }

    public float getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(float thanhTien) {
        this.thanhTien = thanhTien;
    }
    
}
