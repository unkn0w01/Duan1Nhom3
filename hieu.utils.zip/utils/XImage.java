/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;

/**
 *
 * @author buiva
 */
public class XImage {
    public static Image getIcon(){ // static là pt tĩnh, có thể gọi trực tiếp từ lớp , mà không cần khởi tạo 1 đối tượng của lớp đó.
        URL url = XImage.class.getResource("/icon/fpt.png");
        return new ImageIcon(url).getImage();
    }
}
